<?php

namespace Auth;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\command\{
	Command,
	CommandSender
};
use pocketmine\event\Listener;
use pocketmine\event\player\{
	PlayerJoinEvent,
	PlayerQuitEvent,
	PlayerMoveEvent,
	PlayerChatEvent,
	PlayerBlockPickEvent,
	PlayerCommandPreprocessEvent,
	PlayerInteractEvent,
	PlayerDropItemEvent,
	PlayerToggleSprintEvent,
	PlayerBedEnterEvent,
	PlayerBedLeaveEvent,
	PlayerToggleFlightEvent,
	PlayerToggleSneakEvent,
	PlayerItemConsumeEvent
};
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\block\BlockBreakEvent;

class Auth extends PluginBase implements Listener {

	public $password, $auth;

	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		@mkdir($this->getDataFolder());
		$this->password = new Config($this->getDataFolder() . "passwords.yml", Config::YAML);
	}

	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) : bool {
		switch ($cmd->getName()) {
			case "cp":
				if (!isset($args[0]) and count($args) === 1) {
					$sender->sendMessage("§8(§cАвторизация§8) §7Использование: §c/cp <новый пароль>§7.");
					break;
				}
				if (strlen($args[0]) < 6) {
					$sender->sendMessage("§8(§cАвторизация§8) §7Слишком короткий пароль!");
					break;
				}
				if (strlen($args[0]) > 26) {
					$sender->sendMessage("§8(§cАвторизация§8) §7Пароль должен быть не более 21 символа.");
					break;
				}
				$this->password->setNested("players." . strtolower($sender->getName()) . ".password", $args[0]);
				$this->password->save();
				$sender->sendMessage("§8(§cАвторизация§8) §7Вы успешно изменили свой пароль! Ваш новый пароль: §c" . $args[0] . "§r§7.");
				break;
		}
		return true;
	}

	public function onJoin(PlayerJoinEvent $event) {
		$player = $event->getPlayer();
		if (!isset($this->auth[$player->getName()])) {
			$this->auth[$player->getName()] = false;
		}
		if (!$this->auth[$player->getName()]) {
			if (!isset($this->password->get("players")[strtolower($player->getName())])) {
				$player->sendMessage("§8(§cАвторизация§8) §7Данный аккаунт не зарегистрирован!");
				$player->sendMessage("§8(§cАвторизация§8) §7Чтобы зарегистрировать этот аккаунт, придумайте пароль и напишите его в чат.");
				return false;
			} else {
				if ($this->password->getNested("players." . strtolower($player->getName()) . ".ip") == $player->getAddress()) {
					$player->sendMessage("§8(§cАвторизация§8) §7Вы успешно вошли в аккаунт по Вашему IP.");
					$this->auth[$player->getName()] = true;
					return false;
				}
				$player->sendMessage("§8(§cАвторизация§8) §7Введите пароль, который Вы писали при регистрации этого аккаунта.");
			}
		}
	}

	public function onQuit(PlayerQuitEvent $event) {
		$this->auth[$event->getPlayer()->getName()] = false;
	}

	public function onChat(PlayerChatEvent $event) {
		$player = $event->getPlayer();
		$msg = $event->getMessage();
		if ($this->auth[$player->getName()]) {
			if ($msg == $this->password->getNested("players." . strtolower($player->getName()) . ".password")){
				$player->sendMessage("§8(§cАвторизация§8) §7Нельзя писать свой пароль в чат!");
				$event->setCancelled();
			}
			return false;
		}
		if (isset($this->password->getAll()["players"][strtolower($player->getName())])) {
			if ($msg == $this->password->getNested("players." . strtolower($player->getName()) . ".password")) {
				$player->sendMessage("§8(§cАвторизация§8) §7Вы успешно вошли в свой аккаунт!");
				$event->setCancelled();
				$this->password->setNested("players." . strtolower($player->getName()) . ".ip", $player->getAddress());
				$this->password->save();
				$this->auth[$player->getName()] = true;
			} else {
				$player->sendMessage("§8(§cАвторизация§8) §7Неверный пароль!");
				$event->setCancelled();	
			}
			return false;
		}
		if (strlen($msg) < 6) {
			$player->sendMessage("§8(§cАвторизация§8) §7Слишком короткий пароль!");
			$event->setCancelled();
			return false;
		}
		if (strlen($msg) > 26) {
			$player->sendMessage("§8(§cАвторизация§8) §7Пароль должен быть не более 21 символа.");
			$event->setCancelled();
			return false;
		}
		$player->sendMessage("§8(§cАвторизация§8) §7Вы успешно зарегистрировались. Ваш пароль: §c" . $msg . "§7.");
		$this->password->setNested("players." . strtolower($player->getName()) . ".password", $msg);
		$this->password->setNested("players." . strtolower($player->getName()) . ".ip", $player->getAddress());
		$this->auth[$player->getName()] = true;
		$this->password->save();
		$event->setCancelled();
	}

	public function onDrop(PlayerDropItemEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onMove(PlayerMoveEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}
	
	public function onCmd(PlayerCommandPreprocessEvent $event) {
		if (str_replace("/", "", $event->getMessage()) != $event->getMessage()) {
			if ($this->checkAuth($event->getPlayer()) == "1") {
				$event->setCancelled();
			}
		}
	}
	
	public function onInteract(PlayerInteractEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}
	
	public function onBlockBreak(BlockBreakEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}
	
	public function onSprint(PlayerToggleSprintEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onBlockPick(PlayerBlockPickEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onBedEnter(PlayerBedEnterEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onBedLeave(PlayerBedLeaveEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onItemConsume(PlayerItemConsumeEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onToggleSneak(PlayerToggleSneakEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onToggleFlight(PlayerToggleFlightEvent $event) {
		if ($this->checkAuth($event->getPlayer()) == "1") {
			$event->setCancelled();
		}
	}

	public function onDamage(EntityDamageEvent $event) {
		if ($event->getEntity() instanceof Player) {
			if ($this->checkAuth($event->getEntity()) == "1") {
				$event->setCancelled();
			}
		}
	}

	public function checkAuth($player) {
		if (!isset($this->auth[$player->getName()])) {
			$this->auth[$player->getName()] = false;
		}
		if (!$this->auth[$player->getName()]) {
			if (isset($this->password->get("players")[strtolower($player->getName())]))  {
				$player->sendTip("§l§cВы не авторизованы, введите свой пароль в чат!");
			} else {
				$player->sendTip("§l§cВы не зарегистрированы, введите новый пароль в чат!");
			}
			return "1";
		}
		return "0";
	}
}
