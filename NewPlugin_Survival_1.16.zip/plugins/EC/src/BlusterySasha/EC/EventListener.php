<?php

declare(strict_types = 1);

namespace BlusterySasha\EC;

use pocketmine\block\Block;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Armor;
use pocketmine\item\Bow;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\Sword;
use pocketmine\item\Tool;
use pocketmine\utils\TextFormat as TF;
use pocketmine\Player;
use pocketmine\Server;
use jojoe77777\FormAPI\SimpleForm;

class EventListener implements Listener {

    private $plugin;

    public function __construct(Main $plugin)
    {
        $this->plugin = $plugin;
    }

    public function generateEnchants(Item $toEnchant, Block $ectable) : array {
        $bookshelfs = $this->plugin->getBookshelfs($ectable);
        if ($bookshelfs >= 0) {
            $levelSub = 0.20;
        }
        if ($bookshelfs > 5) {
            $levelSub = 0.40;
        }
        if ($bookshelfs > 10) {
            $levelSub = 0.70;
        }
        if ($bookshelfs > 15) {
            $levelSub = 1;
        }
        if ($toEnchant instanceof Sword) {
            $firstEnch = explode(":", $this->plugin->swordEnchantments[array_rand($this->plugin->swordEnchantments)]);
            $secondEnch = explode(":", $this->plugin->swordEnchantments[array_rand($this->plugin->swordEnchantments)]);
            $thirdEnch = explode(":", $this->plugin->swordEnchantments[array_rand($this->plugin->swordEnchantments)]);
            $enchants = array(
                0 => $firstEnch[0].":".rand(1, intval($firstEnch[1] * ($levelSub - 0.15))).":".rand(intval(2 * ($levelSub + 1)), intval(6 * ($levelSub + 1))),
                1 => $secondEnch[0].":".rand(1, intval($secondEnch[1] * ($levelSub - 0.10))).":".rand(intval(6 * ($levelSub + 1)), intval(10 * ($levelSub + 1))),
                2 => $thirdEnch[0].":".rand(2, intval($thirdEnch[1] * ($levelSub))).":".rand(intval(10 * ($levelSub + 1)), intval(15 * ($levelSub + 1)))
            );
        }
        else if ($toEnchant instanceof Bow) {
            $firstEnch = explode(":", $this->plugin->bowEnchantments[array_rand($this->plugin->bowEnchantments)]);
            $secondEnch = explode(":", $this->plugin->bowEnchantments[array_rand($this->plugin->bowEnchantments)]);
            $thirdEnch = explode(":", $this->plugin->bowEnchantments[array_rand($this->plugin->bowEnchantments)]);
            $enchants = array(
                0 => $firstEnch[0] . ":" . rand(1, intval($firstEnch[1] * ($levelSub - 0.15))) . ":" . rand(intval(2 * ($levelSub + 1)), intval(6 * ($levelSub + 1))),
                1 => $secondEnch[0] . ":" . rand(1, intval($secondEnch[1] * ($levelSub - 0.10))) . ":" . rand(intval(6 * ($levelSub + 1)), intval(10 * ($levelSub + 1))),
                2 => $thirdEnch[0] . ":" . rand(2, intval($thirdEnch[1] * ($levelSub))) . ":" . rand(intval(10 * ($levelSub + 1)), intval(15 * ($levelSub + 1)))
            );
                }
        else if ($toEnchant instanceof Tool) {
            $firstEnch = explode(":", $this->plugin->toolEnchantments[array_rand($this->plugin->toolEnchantments)]);
            $secondEnch = explode(":", $this->plugin->toolEnchantments[array_rand($this->plugin->toolEnchantments)]);
            $thirdEnch = explode(":", $this->plugin->toolEnchantments[array_rand($this->plugin->toolEnchantments)]);
            $enchants = array(
                0 => $firstEnch[0].":".rand(1, intval($firstEnch[1] * ($levelSub - 0.15))).":".rand(intval(2 * ($levelSub + 1)), intval(6 * ($levelSub + 1))),
                1 => $secondEnch[0].":".rand(1, intval($secondEnch[1] * ($levelSub - 0.10))).":".rand(intval(6 * ($levelSub + 1)), intval(10 * ($levelSub + 1))),
                2 => $thirdEnch[0].":".rand(2, intval($thirdEnch[1] * ($levelSub))).":".rand(intval(10 * ($levelSub + 1)), intval(15 * ($levelSub + 1)))
            );
        }
        else if ($toEnchant instanceof Armor) {
            $firstEnch = explode(":", $this->plugin->armorEnchantments[array_rand($this->plugin->armorEnchantments)]);
            $secondEnch = explode(":", $this->plugin->armorEnchantments[array_rand($this->plugin->armorEnchantments)]);
            $thirdEnch = explode(":", $this->plugin->armorEnchantments[array_rand($this->plugin->armorEnchantments)]);
            $enchants = array(
                0 => $firstEnch[0].":".rand(1, intval($firstEnch[1] * ($levelSub - 0.15))).":".rand(intval(2 * ($levelSub + 1)), intval(6 * ($levelSub + 1))),
                1 => $secondEnch[0].":".rand(1, intval($secondEnch[1] * ($levelSub - 0.10))).":".rand(intval(6 * ($levelSub + 1)), intval(10 * ($levelSub + 1))),
                2 => $thirdEnch[0].":".rand(2, intval($thirdEnch[1] * ($levelSub))).":".rand(intval(10 * ($levelSub + 1)), intval(15 * ($levelSub + 1)))
            );
        }
        else {
            $enchants = [];
        }
        return $enchants;
    }

    public function openECTUI(Player $player, Item $toEnchant, Block $ectable) {

        $enchants = $this->generateEnchants($toEnchant, $ectable);
        if (empty($enchants)) {
            $player->sendMessage("§cНельзя зачаровать этот предмет!");
            return;
        }
        /*$enchants = array(
            0 => $this->plugin->enchantments[array_rand($this->plugin->enchantments)].":".(1).":".rand(1, 9),
            1 => $this->plugin->enchantments[array_rand($this->plugin->enchantments)].":".rand(1, 2).":".rand(9, 16),
            2 => $this->plugin->enchantments[array_rand($this->plugin->enchantments)].":".rand(2, 3).":".rand(16, 30)
        );*/

        $form = new SimpleForm(function (Player $player, int $data = null) use ($toEnchant, $enchants) {
            $economyAPI = Server::getInstance()->getPluginManager()->getPlugin('EconomyAPI');
            if ($data != null) {
                switch ($data) {
                    case 1:
                        $arr = explode(":",$enchants[0]);
                        $arr[2] = $arr[2] * 15;
                        if ($arr[2] > 200) {
                            $arr[2] = rand(150, 200);
                        }
                        if ($economyAPI->myMoney($player) < $arr[2]) {
                            $player->sendMessage("§cНедостаточно денег!");
                            return;
                        } else {
                            $ench = Enchantment::getEnchantmentByName($arr[0]);
                            if ($toEnchant->getEnchantment($ench->getId())) {
                                $player->sendMessage("§cДанный предмет уже зачарован на этот чар!");
                                return;
                            }
                            $economyAPI->reduceMoney($player, $arr[2]);
                            $level = $arr[1];
                            if ($level <= 0) {
                                $level = 1;
                            }
                            $toEnchant->addEnchantment(new EnchantmentInstance($ench, (int) $level));
                            $player->getInventory()->setItemInHand($toEnchant);
                        }

                        break;
                    case 2:
                        $arr = explode(":",$enchants[1]);
                        $arr[2] = $arr[2] * 15;
                        if ($arr[2] > 200) {
                            $arr[2] = rand(150, 200);
                        }
                        if ($economyAPI->myMoney($player) < $arr[2]) {
                            $player->sendMessage("§cНедостаточно денег!");
                            return;
                        } else {
                            $ench = Enchantment::getEnchantmentByName($arr[0]);
                            if ($toEnchant->getEnchantment($ench->getId())) {
                                $player->sendMessage("§cДанный предмет уже зачарован на этот чар!");
                                return;
                            }
                            $economyAPI->reduceMoney($player, $arr[2]);
                            $level = $arr[1];
                            if ($level <= 0) {
                                $level = 1;
                            }
                            $toEnchant->addEnchantment(new EnchantmentInstance($ench, (int) $level));
                            $player->getInventory()->setItemInHand($toEnchant);
                        }
                        break;
                    case 3:
                        $arr = explode(":",$enchants[2]);
                        $arr[2] = $arr[2] * 15;
                        if ($arr[2] > 200) {
                            $arr[2] = rand(150, 200);
                        }
                        if ($economyAPI->myMoney($player) < $arr[2]) {
                            $player->sendMessage("§cНедостаточно денег!");
                            return;
                        } else {
                            $ench = Enchantment::getEnchantmentByName($arr[0]);
                            if ($toEnchant->getEnchantment($ench->getId())) {
                                $player->sendMessage("§cДанный предмет уже зачарован на этот чар!");
                                return;
                            }
                            $economyAPI->reduceMoney($player, $arr[2]);
                            $level = $arr[1];
                            if ($level <= 0) {
                                $level = 1;
                            }
                            
                            if ($toEnchant->getId() !== $player->getInventory()->getItemInHand()->getId()){
                                $player->sendMessage(TF::RED . "Нельзя зачаровать этот чар.");
                                return;
                            }
                            
                            $toEnchant->addEnchantment(new EnchantmentInstance($ench, (int) $level));
                            $player->getInventory()->setItemInHand($toEnchant);
                        }
                        break;
                    default:
                        break;
                }
            }
        });

        $form->setTitle("Зачарование: " . $toEnchant->getName());
        $form->addButton("§l§cВЫЙТИ");
        foreach ($enchants as $ec) {
            $arr = explode(":", $ec);
            $lvl = $arr[1];
            if ($lvl <= 0) {
                $lvl = 1;
            }
            $arr[2] = $arr[2] * 15;
            if ($arr[2] > 200) {
                $arr[2] = rand(150, 200);
            }
            $form->addButton($arr[0] . " (" . $lvl . ") за " . $arr[2] . " монет");
        }
        $form->setContent("Зачаровать предмет в руке");
        $form->sendToPlayer($player);

    }

    public function onTouch(PlayerInteractEvent $event) {
        $block = $event->getBlock();
        if ($block->getId() === Block::ENCHANTING_TABLE || $block->getId() === Block::ENCHANTMENT_TABLE) {
            $event->setCancelled(true);
            if ($event->getPlayer()->isSneaking() === false) {
                $toEnchant = $event->getItem();
                $this->openECTUI($event->getPlayer(), $toEnchant, $block);
            }
        }

    }

}