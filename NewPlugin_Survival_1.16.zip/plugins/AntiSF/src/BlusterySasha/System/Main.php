<?php

 /*
 * Плагин был написан группой NewPlugins.
 * Полное или частичное копирование запрещено.
 */

namespace BlusterySasha\System;

use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

	public function onEnable() {
		if (!is_dir($this->getDataFolder())) {
			mkdir($this->getDataFolder());
		}
		$this->players = array();
		$this->cfg = (new Config($this->getDataFolder(). "config.yml", Config::YAML, [
			"enable" => array(
				"enableMessage" => true,
				"text" => "Плагин System (by BlusterySasha) запущен!"
			),
			"spam" => array(
				"domains" => array(
					"ru",
					"net"
				),
				"kick" => array(
					"kickPlayer" => false,
					"text" => "Вы были кикнуты за рекламу серверов!"
				),
				"text" => "{player}, Вы не можете рекламировать сервера!",
				"warn" => array(
					"warnAdmins" => true,
					"warnPermission" => "system.broadcast.spam",
					"text" => "Игрок {player} рекламирует сервер: {message}."
				)
			),
			"flood" => array(
				"seconds" => 3,
				"text" => "{player}, пожалуйста, не отправляйте сообщения так быстро. Подождите {time} сек.",
				"warn" => array(
					"warnAdmins" => true,
					"warnPermission" => "system.broadcast.flood",
					"text" => "Игрок {player} флудит: {message}."
				)
			),
			"bypassPermission" => array(
				"all" => "system.bypass",
				"flood" => "system.bypass.flood",
				"spam" => "system.bypass.spam"
			)
		]))->getAll();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		if ($this->cfg["enable"]["enableMessage"]) {
			$this->getLogger()->info($this->cfg["enable"]["text"]);
		}
	}

	public function onChat(PlayerChatEvent $event) {
		if (!$event->getPlayer()->hasPermission($this->cfg["bypassPermission"]["all"])) {
			$break = false;
			if (!$event->getPlayer()->hasPermission($this->cfg["bypassPermission"]["flood"])) {
				if (!isset($this->players[strtolower($event->getPlayer()->getName())])) {
					$this->players[strtolower($event->getPlayer()->getName())] = (time() + (int) $this->cfg["flood"]["seconds"]);
				} else {
					if ($this->players[strtolower($event->getPlayer()->getName())] >= time()) {
						$break = true;
						$message = str_replace("{time}", ($this->players[strtolower($event->getPlayer()->getName())] - time()), $this->cfg["flood"]["text"]);
						$message = str_replace("{player}", $event->getPlayer()->getName(), $message);
						$event->getPlayer()->sendMessage($message);
						if ($this->cfg["flood"]["warn"]["warnAdmins"]) {
							$warnAdmins = str_replace("{message}", $event->getMessage(), $this->cfg["flood"]["warn"]["text"]);
							$warnAdmins = str_replace("{player}", $event->getPlayer()->getName(), $warnAdmins);
							$this->getLogger()->info($warnAdmins);
							foreach ($this->getServer()->getOnlinePlayers() as $players) {
								if ($players->hasPermission($this->cfg["flood"]["warn"]["warnPermission"])) {
									$players->sendMessage($warnAdmins);
								}
							}
						}
						$event->setCancelled();
					} else {
						$this->players[strtolower($event->getPlayer()->getName())] = (time() + (int) $this->cfg["flood"]["seconds"]);
					}
				}
			}
			if (!$event->getPlayer()->hasPermission($this->cfg["bypassPermission"]["spam"])) {
				if (!$break) {
					foreach ($this->cfg["spam"]["domains"] as $domains) {
						if (strpos($event->getMessage(), $domains) !== false) {
							if ($this->cfg["spam"]["warn"]["warnAdmins"]) {
								$warnAdmins = str_replace("{message}", $event->getMessage(), $this->cfg["spam"]["warn"]["text"]);
								$warnAdmins = str_replace("{player}", $event->getPlayer()->getName(), $warnAdmins);
								$this->getLogger()->info($warnAdmins);
								foreach ($this->getServer()->getOnlinePlayers() as $players) {
									if ($players->hasPermission($this->cfg["spam"]["warn"]["warnPermission"])) {
										$players->sendMessage($warnAdmins);
									}
								}
							}
							if (!$this->cfg["spam"]["kick"]["kickPlayer"]) {
								$event->getPlayer()->sendMessage(str_replace("{player}", $event->getPlayer()->getName(), $this->cfg["spam"]["text"]));
							} else {
								$event->getPlayer()->kick($this->cfg["spam"]["kick"]["text"], false);
							}
							$event->setCancelled();
							break;
						}
					}
				}
			}
		}
	}
}
?>