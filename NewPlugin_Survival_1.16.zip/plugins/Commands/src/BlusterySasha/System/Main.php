<?php

namespace BlusterySasha\System;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener {

	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("Плагин System запущен! Автор: BlusterySasha");
	}
	
	public function onCommand(CommandSender $s, Command $cmd, string $label, array $args) : bool {
		if ($cmd->getName() == "say") {
			if (isset($args[0])) {
				$this->getServer()->broadcastMessage("§c§lВНИМАНИЕ! §r§fx §7" . $s->getName() . ": §b" . $args[0]);
			} else {
				$s->sendMessage("§e§lУкажите сообщение!");
			}
			return true;
		}

		if ($cmd->getName() == "sleep") {
			$s->sleepOn(new Vector3($s->getX(), $s->getY() + 1, $s->getZ()));
			return true;
		}

		if ($cmd->getName() == "jump") {
			$s->teleport(new Vector3($s->getX(), $s->getLevel()->getHighestBlockAt($s->getFloorX(), $s->getFloorZ()) + 1, $s->getZ())); 
			$s->sendMessage("§e§lВы успешно телепортированы!");
			return true;
		}
		return true;
	}

	public function onJoin(PlayerJoinEvent $event) {
		$event->getPlayer()->setDisplayName(str_replace(" ", "_", $event->getPlayer()->getName()));
	}
}
?>