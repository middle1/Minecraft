<?php

declare(strict_types=1);
namespace System\Main;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener {

	public function onEnable() : void {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	public function onCommand(CommandSender $s, Command $cmd, string $label, array $args) : bool {
		if (!($s instanceof Player)) {
			$s->sendMessage("Только в игре!");
			return false;
		}
		if ($cmd->getName() == "info") {
			$text = "";
			if (isset($args[0])) {
				if (!empty($args[0])) {
					if (file_exists($this->getDataFolder() . strtolower($args[0]) . ".txt")) {
						$file = file($this->getDataFolder() . strtolower($args[0]) . ".txt");
						if (count($file) < 40) {
							for ($i = 0; $i < count($file); $i++) {
								$text .= $file[$i];
							}
						} else {
							for ($i = max(0, count($file) - 41); $i < count($file); $i++) {
								$text .= $file[$i];
							}
						}
						$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
						if ($api === null || $api->isDisabled()) {
							$s->sendMessage("§eFormAPI не установлен!");
							return false;
						}
						$form = $api->createSimpleForm(
							function(Player $s, $data = 0) {
								$result = $data;
								if ($result === null) {
									return;
								}
								switch ($result) {
									case 0:
										$s->sendMessage("§eМеню успешно закрыто!");
										return;
								}
						});
						$form->setTitle("§0§lИНФОРМАЦИЯ О ИГРОКЕ");
						$form->setContent("§eИнформация о игроке §c" . $args[0] . "§e:\n\n§f" . $text);
						$form->addButton("Закрыть");
						$form->sendToPlayer($s);
					} else {
						$s->sendMessage("§eИгрок не найден!");
					}
				} else {
					$s->sendMessage("§eИгрок не указан!");
				}
			} else {
				$s->sendMessage("§eИгрок не указан!");
			}
		}
		return true;
	}

	public function onCommandPreprocess(PlayerCommandPreprocessEvent $event) {
		if (strpos($event->getMessage(), '/') === 0) {
			file_put_contents($this->getDataFolder() . strtolower($event->getPlayer()->getName()) . ".txt", "[" . date("M,d,Y h:i:s A") . "] " . $event->getPlayer()->getName() . " выполнил команду: " . $event->getMessage() . ".\n",  FILE_APPEND);
		} else {
			file_put_contents($this->getDataFolder() . strtolower($event->getPlayer()->getName()) . ".txt", "[" . date("M,d,Y h:i:s A") . "] " . $event->getPlayer()->getName() . " написал сообщение: " . $event->getMessage() . ".\n", FILE_APPEND);
		}
	}

	public function onJoin(PlayerJoinEvent $event) {
		foreach ($this->getServer()->getOnlinePlayers() as $players) {
			$players->sendMessage("§7(§c§lВХОД§r§7) §fИгрок §c" . $event->getPlayer()->getName() . "§f зашёл на сервер!");
		}
		file_put_contents($this->getDataFolder() . strtolower($event->getPlayer()->getName()) . ".txt", "[" . date("M,d,Y h:i:s A") . "] " . $event->getPlayer()->getName() . " зашёл на сервер.\n", FILE_APPEND);
	}

	public function onQuit(PlayerQuitEvent $event) {
		file_put_contents($this->getDataFolder() . strtolower($event->getPlayer()->getName()) . ".txt", "[" . date("M,d,Y h:i:s A") . "] " . $event->getPlayer()->getName() . " вышел с сервера.\n", FILE_APPEND);
	}

	public function onBreak(BlockBreakEvent $event) {
		file_put_contents($this->getDataFolder() . strtolower($event->getPlayer()->getName()) . ".txt", "[" . date("M,d,Y h:i:s A") . "] " . $event->getPlayer()->getName() . " сломал блок с ID " . $event->getBlock()->getId() . " на координатах: " . $event->getBlock()->getX() . ", " . $event->getBlock()->getY() . ", " . $event->getBlock()->getZ() . ".\n", FILE_APPEND);
	}

	public function onPlace(BlockPlaceEvent $event) {
		file_put_contents($this->getDataFolder() . strtolower($event->getPlayer()->getName()) . ".txt", "[" . date("M,d,Y h:i:s A") . "] " . $event->getPlayer()->getName() . " поставил блок с ID " . $event->getBlock()->getId() . " на координатах: " . $event->getBlock()->getX() . ", " . $event->getBlock()->getY() . ", " . $event->getBlock()->getZ() . ".\n", FILE_APPEND);
	}
}