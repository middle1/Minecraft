<?php
	
	namespace BanSystem;
	
	use pocketmine\Player;
	use pocketmine\utils\Config;
	use pocketmine\scheduler\Task;
	use pocketmine\event\Listener;
	use pocketmine\command\Command;
	use pocketmine\plugin\PluginBase;
	use pocketmine\command\CommandSender;
	use pocketmine\event\player\PlayerChatEvent;
	use pocketmine\event\player\PlayerMoveEvent;
	use pocketmine\event\player\PlayerPreLoginEvent;
	
	class vTask extends Task {
		
		private $vMain;
		
		public function __construct(vMain $vMain) {
			$this->vMain = $vMain;
		}
		
		public function onRun($currentTick) {
			foreach($this->vMain->ban->getAll() as $nickname => $ban) {
				if($ban["TimeUnban"] <= time()) {
					$this->vMain->ban->remove($nickname);
					$this->vMain->ban->save();
				}
			}
			
			foreach($this->vMain->mute->getAll() as $nickname => $mute) {
				if($mute["TimeUnmute"] <= time()) {
					$this->vMain->mute->remove($nickname);
					$this->vMain->mute->save();
				}
			}
			
			foreach($this->vMain->freeze->getAll() as $nickname => $freeze) {
				if($freeze["TimeUnfreeze"] <= time()) {
					$this->vMain->freeze->remove($nickname);
					$this->vMain->freeze->save();
					
					$player = $this->vMain->getServer()->getPlayer($nickname);
					
					if($player instanceof Player) {
						$player->setImmobile(false);
					}
				}
			}
		}
		
	}
	
	class vMain extends PluginBase implements Listener {
		
		public $config, $ban, $mute, $freeze;
		
		public function onEnable() {
			$this->getServer()->getPluginManager()->registerEvents($this, $this);
			
			$this->groups = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
			
			if(!empty($this->groups)) {
				$this->ban = new Config($this->getDataFolder() . "ban.yml", Config::YAML);
				$this->mute = new Config($this->getDataFolder() . "mute.yml", Config::YAML);
				$this->freeze = new Config($this->getDataFolder() . "freeze.yml", Config::YAML);
				$this->config = new Config($this->getDataFolder() . "config.yml", Config::YAML, array(
					"ConsoleName" => "Сервер",
					"Messages" => array(
						"NoPermission" => "У Вас недостаточно прав!",
						"Bans" => array(
							"Using" => "Используйте /bans <никнейм>"
						),
						"Ban" => array(
							"Using" => "Используйте /iban <никнейм> <время в минутах> <причина>",
							"WrongTime" => "Укажите время в правильном формате!",
							"BigTime" => "Лимит времени блокировки игроков для Вашей привилегии — {%limit%} мин.",
							"AlradyBanned" => "Игрок {%player%} уже был заблокирован на сервере!",
							"SuccessBan" => "Игрок {%sender%} заблокировал игрока {%player%} по причине {%reason%}, на {%time%} мин.",
							"PlayerClose" => "Вы были заблокированы на сервере игроком {%sender%}\nПо причине {%reason%}, на {%time%} мин."
						),
						"Mute" => array(
							"Using" => "Используйте /mute <никнейм> <время в минутах> <причина>",
							"WrongTime" => "Укажите время в правильном формате!",
							"BigTime" => "Лимит времени блокировки чата игроков для Вашей привилегии — {%limit%} мин.",
							"AlradyMuted" => "У игрока {%player%} уже был заблокирован чат!",
							"SuccessMute" => "Игрок {%sender%} заблокировал чат игрока {%player%} по причине {%reason%}, на {%time%} мин.",
							"PlayerMessage" => "Ваш чат был заблокирован игроком {%sender%} по причине {%reason%}, на {%time%} мин."
						),
						"Freeze" => array(
							"Using" => "Используйте /freeze <никнейм> <время в минутах>",
							"WrongTime" => "Укажите время в правильном формате!",
							"BigTime" => "Лимит времени заморозки игроков для Вашей привилегии — {%limit%} мин.",
							"AlradyFreezed" => "Игрок {%player%} уже был заморожен!",
							"SuccessFreeze" => "Игрок {%sender%} заморозил игрока {%player%} на {%time%} мин.",
							"PlayerMessage" => "Вы были заблокированы на сервере игроком {%sender%} на {%time%} мин."
						),
						"Unban" => array(
							"Using" => "Используйте /unban <никнейм>",
							"PlayerNotBanned" => "Данный игрок не был заблокирован!",
							"SuccessUnban" => "Вы успешно разблокировали игрока {%player%}",
							"PlayerWasUnbanned" => "{%player%} разблокировал игрока {%player%}"
						),
						"Unmute" => array(
							"Using" => "Используйте /unmute <никнейм>",
							"PlayerNotMuted" => "У данного игрока не был заблокирован чат!",
							"SuccessUnmute" => "Вы успешно разблокировали чат игрока {%player%}"
						),
						"Unfreeze" => array(
							"Using" => "Используйте /unfreeze <никнейм>",
							"PlayerNotFreezed" => "Данный игрок не был заморожен!",
							"SuccessUnfreeze" => "Вы успешно разморозили игрока {%player%}"
						)
					),
					"MaxTime" => array(
						"Ban" => array(
							"BaseTime" => 5,
							"demogroup" => 10
						),
						"Mute" => array(
							"BaseTime" => 5,
							"demogroup" => 10
						),
						"Freeze" => array(
							"BaseTime" => 5,
							"demogroup" => 10
						)
					)
				));
				
				$this->getScheduler()->scheduleRepeatingTask(new vTask($this), 20 * 5);
			} else {
				$this->getServer()->getLogger()->error("vBanSystem › Отсутствует плагин PurePerms!");
				$this->getServer()->getLogger()->info("vBanSystem › Выключение плагина...");
				
				$this->getServer()->getPluginManager()->disablePlugin($this);
			}
		}
		
		public function onCommand(CommandSender $sender, Command $command, $label, array $args) : bool {
			switch($command->getName()) {
				
				case "bans":
					if(!$sender->hasPermission("vbansystem.bans")) {
						$sender->sendMessage($this->config->getNested("Messages.NoPermission"));
					} else if(empty($args)) {
						$sender->sendMessage($this->config->getNested("Messages.Bans.Using"));
					} else {
						$blocking = strtolower($args[0]);
						$bans = array_filter($this->ban->getAll(), function($nickname, $ban) {
							if($ban["Blocking"] == $blocking) {
								return true;
							} else return false;
						}, ARRAY_FILTER_USE_BOTH);
						
						if(empty($bans)) {
							$sender->sendMessage("Указанный игрок не блокировал других игроков!");
						} else {
							$output = array();
							
							foreach($bans as $nickname => $ban) {
								array_push($output, $nickname . ": время › " . $ban["Time"] . " мин., причина › " . $ban["Reason"]);
							}
							
							$sender->sendMessage("Указанный игрок заблокировал следующих игроков: " . implode(", ", $output));
						}
					}
				break;
				
				case "iban":
					if(!$sender->hasPermission("vbansystem.ban")) {
						$sender->sendMessage($this->config->getNested("Messages.NoPermission"));
					} else if(empty($args) or count($args) < 3) {
						$sender->sendMessage($this->config->getNested("Messages.Ban.Using"));
					} else if(!is_numeric($args[1]) and !$sender->hasPermission("vbansystem.ban.forever") or $args[1] < 1 and !$sender->hasPermission("vbansystem.ban.forever")) {
						$sender->sendMessage($this->config->getNested("Messages.Ban.WrongTime"));
					} else {
						if ($sender->hasPermission("vbansystem.ban.forever")) {
							if (strtolower($args[1]) == "forever") {
								$time = PHP_INT_MAX;
							} else {
								if ((int)$args[1] < 1) {
									$sender->sendMessage($this->config->getNested("Messages.Ban.WrongTime"));
									return false;
								}
								$time = (int)$args[1];
							}
						} else {
							if ((int)$args[1] < 1) {
								$sender->sendMessage($this->config->getNested("Messages.Ban.WrongTime"));
								return false;
							}
							$time = (int)$args[1];
						}
						$reason = implode(" ", array_slice($args, 2));
						$player = $this->getServer()->getPlayer(strtolower($args[0]));
						$nickname = $player instanceof Player ? $player->getName() : strtolower($args[0]);

						if (!$sender instanceof Player) {
							$limit = PHP_INT_MAX;
							$group = "[КОНСОЛЬ]";
						} else {
							$group = strtolower($this->groups->getUserDataMgr()->getGroup($this->getServer()->getPlayer($sender->getName()))->getName());
							
							if(empty($this->config->getNested("MaxTime.Ban")[$group])) {
								$limit = (int)$this->config->getNested("MaxTime.Ban.BaseTime");
							} else $limit = (int)$this->config->getNested("MaxTime.Ban")[$group];
						}
						
						if($time > $limit and $limit != 0) {
							$message = $this->config->getNested("Messages.Ban.BigTime");
							$message = str_replace("\n", PHP_EOL, $message);
							$message = str_replace("{%limit%}", $limit, $message);
							$message = str_replace("{%group%}", $group, $message);
							$message = str_replace("{%player%}", $nickname, $message);
							$message = str_replace("{%sender%}", $sender->getName(), $message);
							
							$sender->sendMessage($message);
						} else if($this->ban->exists(strtolower($nickname))) {
							$message = $this->config->getNested("Messages.Ban.AlradyBanned");
							$message = str_replace("\n", PHP_EOL, $message);
							$message = str_replace("{%limit%}", $limit, $message);
							$message = str_replace("{%group%}", $group, $message);
							$message = str_replace("{%player%}", $nickname, $message);
							$message = str_replace("{%sender%}", $sender->getName(), $message);
							
							$sender->sendMessage($message);
						} else {
							$this->ban->set(strtolower($nickname), array(
								"TimeUnban" => time() + 60 * $time,
								"Blocking" => $sender->getName(),
								"Reason" => $reason,
								"Time" => $time
							));
							
							$this->ban->save();
							
							if ($time >= PHP_INT_MAX) {
								$time = "навсегда";
							}
							$message = $this->config->getNested("Messages.Ban.SuccessBan");
							$message = str_replace("\n", PHP_EOL, $message);
							$message = str_replace("{%time%}", $time, $message);
							$message = str_replace("{%limit%}", $limit, $message);
							$message = str_replace("{%group%}", $group, $message);
							$message = str_replace("{%reason%}", $reason, $message);
							$message = str_replace("{%player%}", $nickname, $message);
							$message = str_replace("{%sender%}", $sender->getName(), $message);
							
							$this->getServer()->broadcastMessage($message);
							
							if($player instanceof Player) {
								$message = $this->config->getNested("Messages.Ban.PlayerClose");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%time%}", $time, $message);
								$message = str_replace("{%reason%}", $reason, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
							
								$player->close("", $message);
							}
						}
					}
				break;
				
				case "mute":
					if(!$sender->hasPermission("vbansystem.mute")) {
						$sender->sendMessage($this->config->getNested("Messages.NoPermission"));
					} else if(empty($args) or count($args) < 3) {
						$sender->sendMessage($this->config->getNested("Messages.Mute.Using"));
					} else if(!is_numeric($args[1]) or $args[1] < 1) {
						$sender->sendMessage($this->config->getNested("Messages.Mute.WrongTime"));
					} else {
						$player = $this->getServer()->getPlayer(strtolower($args[0]));
						
						if(!$player instanceof Player) {
							$sender->sendMessage($this->config->getNested("Messages.Mute.PlayerNotFound"));
						} else {
							$time = (int)$args[1];
							$nickname = $player->getName();
							$reason = implode(" ", array_slice($args, 2));
							$group = strtolower($this->groups->getUserDataMgr()->getGroup($this->getServer()->getPlayer($sender->getName()))->getName());
							
							if(empty($this->config->getNested("MaxTime.Mute")[$group])) {
								$limit = (int)$this->config->getNested("MaxTime.Mute.BaseTime");
							} else $limit = (int)$this->config->getNested("MaxTime.Mute")[$group];
							
							if($time > $limit and $limit != 0) {
								$message = $this->config->getNested("Messages.Mute.BigTime");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%limit%}", $limit, $message);
								$message = str_replace("{%group%}", $group, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$sender->sendMessage($message);
							} else if($this->mute->exists(strtolower($nickname))) {
								$message = $this->config->getNested("Messages.Mute.AlradyMuted");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%limit%}", $limit, $message);
								$message = str_replace("{%group%}", $group, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$sender->sendMessage($message);
							} else {
								$this->mute->set(strtolower($nickname), array(
									"TimeUnmute" => time() + 60 * $time,
									"Muting" => $sender->getName(),
									"Reason" => $reason,
									"Time" => $time
								));
								
								$this->mute->save();
								
								$message = $this->config->getNested("Messages.Mute.SuccessMute");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%time%}", $time, $message);
								$message = str_replace("{%limit%}", $limit, $message);
								$message = str_replace("{%group%}", $group, $message);
								$message = str_replace("{%reason%}", $reason, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$this->getServer()->broadcastMessage($message);
								
								$message = $this->config->getNested("Messages.Mute.PlayerMessage");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%time%}", $time, $message);
								$message = str_replace("{%reason%}", $reason, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$player->sendMessage($message);
							}
						}
					}
				break;
				
				case "freeze":
					if(!$sender->hasPermission("vbansystem.freeze")) {
						$sender->sendMessage($this->config->getNested("Messages.NoPermission"));
					} else if(empty($args) or count($args) < 2) {
						$sender->sendMessage($this->config->getNested("Messages.Freeze.Using"));
					} else if(!is_numeric($args[1]) or $args[1] < 1) {
						$sender->sendMessage($this->config->getNested("Messages.Freeze.WrongTime"));
					} else {
						$player = $this->getServer()->getPlayer(strtolower($args[0]));
						
						if(!$player instanceof Player) {
							$sender->sendMessage($this->config->getNested("Messages.Freeze.PlayerNotFound"));
						} else {
							$time = (int)$args[1];
							$nickname = $player->getName();
							$group = strtolower($this->groups->getUserDataMgr()->getGroup($this->getServer()->getPlayer($sender->getName()))->getName());
							
							if(empty($this->config->getNested("MaxTime.Freeze")[$group])) {
								$limit = (int)$this->config->getNested("MaxTime.Freeze.BaseTime");
							} else $limit = (int)$this->config->getNested("MaxTime.Freeze")[$group];
							
							if($time > $limit and $limit != 0) {
								$message = $this->config->getNested("Messages.Freeze.BigTime");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%limit%}", $limit, $message);
								$message = str_replace("{%group%}", $group, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$sender->sendMessage($message);
							} else if($this->freeze->exists(strtolower($nickname))) {
								$message = $this->config->getNested("Messages.Freeze.AlradyFreezed");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%limit%}", $limit, $message);
								$message = str_replace("{%group%}", $group, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$sender->sendMessage($message);
							} else {
								$this->freeze->set(strtolower($nickname), array(
									"TimeUnfreeze" => time() + 60 * $time,
									"Muting" => $sender->getName(),
									"Time" => $time
								));
								
								$this->freeze->save();
								
								$message = $this->config->getNested("Messages.Freeze.SuccessFreeze");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%time%}", $time, $message);
								$message = str_replace("{%limit%}", $limit, $message);
								$message = str_replace("{%group%}", $group, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$this->getServer()->broadcastMessage($message);
								
								$message = $this->config->getNested("Messages.Freeze.PlayerMessage");
								$message = str_replace("\n", PHP_EOL, $message);
								$message = str_replace("{%time%}", $time, $message);
								$message = str_replace("{%player%}", $nickname, $message);
								$message = str_replace("{%sender%}", $sender->getName(), $message);
								
								$player->sendMessage($message);
							}
						}
					}
				break;
				
				case "unban":
					if(!$sender->hasPermission("vbansystem.unban")) {
						$sender->sendMessage($this->config->getNested("Messages.NoPermission"));
					} else if(empty($args)) {
						$sender->sendMessage($this->config->getNested("Messages.Unban.Using"));
					} else {
						$nickname = strtolower($args[0]);
						
						if(!$this->ban->exists($nickname)) {
							$sender->sendMessage($this->config->getNested("Messages.Unban.PlayerNotBanned"));
						} else {
							$this->ban->remove($nickname);
							$this->ban->save();
							
							$this->getServer()->broadcastMessage(str_replace("{%player%}", $nickname, str_replace("{%sender%}", $sender->getName(), $this->config->getNested("Messages.Unban.PlayerWasUnbanned"))));
							$message = $this->config->getNested("Messages.Unban.SuccessUnban");
							$message = str_replace("\n", PHP_EOL, $message);
							$message = str_replace("{%player%}", $nickname, $message);
							
							$sender->sendMessage($message);
						}
					}
				break;
				
				case "unmute":
					if(!$sender->hasPermission("vbansystem.unmute")) {
						$sender->sendMessage($this->config->getNested("Messages.NoPermission"));
					} else if(empty($args)) {
						$sender->sendMessage($this->config->getNested("Messages.Unmute.Using"));
					} else {
						$nickname = strtolower($args[0]);
						
						if(!$this->mute->exists($nickname)) {
							$sender->sendMessage($this->config->getNested("Messages.Unmute.PlayerNotMuted"));
						} else {
							$this->mute->remove($nickname);
							$this->mute->save();
							
							$message = $this->config->getNested("Messages.Unmute.SuccessUnmute");
							$message = str_replace("\n", PHP_EOL, $message);
							$message = str_replace("{%player%}", $nickname, $message);
							
							$sender->sendMessage($message);
							
							$player = $this->getServer()->getPlayer($nickname);
							
							if($player instanceof Player) {
								$player->setImmobile(false);
							}
						}
					}
				break;
				
				case "unfreeze":
					if(!$sender->hasPermission("vbansystem.unfreeze")) {
						$sender->sendMessage($this->config->getNested("Messages.NoPermission"));
					} else if(empty($args)) {
						$sender->sendMessage($this->config->getNested("Messages.Unfreeze.Using"));
					} else {
						$nickname = strtolower($args[0]);
						
						if(!$this->freeze->exists($nickname)) {
							$sender->sendMessage($this->config->getNested("Messages.Unfreeze.PlayerNotFreezed"));
						} else {
							$this->freeze->remove($nickname);
							$this->freeze->save();
							
							$message = $this->config->getNested("Messages.Unfreeze.SuccessUnfreeze");
							$message = str_replace("\n", PHP_EOL, $message);
							$message = str_replace("{%player%}", $nickname, $message);
							
							$sender->sendMessage($message);
							
							$player = $this->getServer()->getPlayer($nickname);
							
							if($player instanceof $player) {
								$player->setImmobile(false);
							}
						}
					}
				break;
				
			}
			
			return true;
		}
		
		public function onPPLE(PlayerPreLoginEvent $event) {
			$player = $event->getPlayer();
			
			if($this->ban->exists(strtolower($player->getName()))) {
				$ban = $this->ban->get(strtolower($player->getName()));
				
				if($ban["TimeUnban"] > time()) {
					$message = $this->config->getNested("Messages.Ban.PlayerClose");
					$message = str_replace("\n", PHP_EOL, $message);
					$message = str_replace("{%time%}", $ban["Time"], $message);
					$message = str_replace("{%reason%}", $ban["Reason"], $message);
					$message = str_replace("{%player%}", $player->getName(), $message);
					$message = str_replace("{%sender%}", $ban["Blocking"], $message);
					
					$event->setKickMessage($message);
					$event->setCancelled(true);
				}
			}
		}
		
		public function onPCE(PlayerChatEvent $event) {
			$player = $event->getPlayer();
			
			if($this->mute->exists(strtolower($player->getName()))) {
				$mute = $this->mute->get(strtolower($player->getName()));
				
				if($mute["TimeUnmute"] > time()) {
					$message = $this->config->getNested("Messages.Mute.PlayerMessage");
					$message = str_replace("\n", PHP_EOL, $message);
					$message = str_replace("{%time%}", $mute["Time"], $message);
					$message = str_replace("{%reason%}", $mute["Reason"], $message);
					$message = str_replace("{%player%}", $player->getName(), $message);
					$message = str_replace("{%sender%}", $mute["Muting"], $message);
					
					$player->sendMessage($message);
					$event->setCancelled(true);
				}
			}
		}
		
		public function onPME(PlayerMoveEvent $event) {
			$player = $event->getPlayer();
			
			if($this->freeze->exists(strtolower($player->getName()))) {
				$freeze = $this->freeze->get(strtolower($player->getName()));
				
				if($freeze["TimeUnfreeze"] > time()) {
					$player->setImmobile(true);
				}
			}
		}
		
	}
	
?>