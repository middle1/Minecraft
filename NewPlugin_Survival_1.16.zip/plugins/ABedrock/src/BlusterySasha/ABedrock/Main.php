<?php
namespace BlusterySasha\ABedrock;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\Player;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\block\Block;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener {

    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

	public function onBreak(BlockBreakEvent $event) {
        $player = $event->getPlayer();
        $blocks = $event->getBlock()->getId();
        $blacklist = [Block::BEDROCK];
        if (in_array($blocks, $blacklist)) {
			$player->sendTip("§l§cВы не можете ломать данный блок!");
            $event->setCancelled();
            return;
        }
    }
}
