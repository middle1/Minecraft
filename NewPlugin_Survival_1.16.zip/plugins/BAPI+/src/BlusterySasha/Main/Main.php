<?php

 /*
 * Плагин был написан группой NewPlugins.
 * Полное или частичное копирование запрещено.
 */

namespace BlusterySasha\Main;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\block\Block;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\math\AxisAlignedBB;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

	public function onEnable() : void {
		$defaults = array(
			"infoCommands" => array(
				1 => array(
					"name" => "ban",
					"info" => "Заблокировать игрока",
					"usage" => "/ban <игрок> <время> <причина>"
				),
				2 => array(
					"name" => "kick",
					"info" => "Кикнуть игрока",
					"usage" => "/kick <игрок> <причина>"
				)
			)
		);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML, $defaults);
		if (!is_dir($this->getDataFolder())) {
			mkdir($this->getDataFolder());
		}
		$this->getLogger()->info("§e§lПлагин успешно запущен!");
	}

	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args) : bool {
		if (!($player instanceof Player)) {
			$player->sendMessage("Только в игре!");
			return false;
		}
		if ($cmd->getName() == "cmdinfo") {
			if (!isset($args[0])) {
				$player->sendMessage("§eУкажите команду!");
				return false;
			}
			$deny = false;
			foreach ($this->cfg->getAll()["infoCommands"] as $commands) {
				if (strtolower($args[0]) == strtolower($commands["name"])) {
					$usage = $commands["usage"];
					$info = $commands["info"];
					break;
				}
			}
			if (!isset($usage, $info)) {
				$deny = true;
				$denyMessage = "§eКоманда ''" . $args[0] . "'' не найдена!";
			}
			if ($deny) {
				$player->sendMessage($denyMessage);
				return false;
			}
			$player->sendMessage("§eИнформация о команде §c/" . strtolower($args[0]) . "§7:");
			$player->sendMessage("§eОписание: §c" . $info . "§7.");
			$player->sendMessage("§eИспользование: §c" . $usage . "§7.");
		} elseif ($cmd->getName() == "clear") {
			$player->getInventory()->clearAll();
			$player->sendMessage("§eИнвентарь успешно очищен.");
		} elseif ($cmd->getName() == "clearchat") {
			$messages = 0;
			$message = "";
			while ($messages < 100) {
				$messages++;
				$message .= " \n";
			}
			foreach ($this->getServer()->getOnlinePlayers() as $players) {
				$players->sendMessage($message);
				$players->sendMessage("§eЧат был очищен игроков §c" . $player->getName() . "§7.");
			}
		} elseif ($cmd->getName() == "donate") {
			$donate = "\n1. Fly: /fly, /kick";
			$donate .= "\n2. God: /rtp, /tp";
			$donate .= "\n3. King: /tpr, /menu";
			$player->sendMessage("§eСписок доната:" . $donate);
		} elseif ($cmd->getName() == "near") {
			$radius = 200;
			foreach ($player->getLevel()->getNearbyEntities(new AxisAlignedBB($player->getFloorX() - $radius, $player->getFloorY() - $radius, $player->getFloorZ() - $radius, $player->getFloorX() + $radius, $player->getFloorY() + $radius, $player->getFloorZ() + $radius), $player) as $e) {
				if ($e instanceof Player) {
					$players[] = $e;
				}
			}
			if (isset($players)) {
				$near = " " . $player->getName();
				foreach ($players as $nears) {
					if (strtolower($nears) != strtolower($player->getName())) {
						$near .= ", " . $nears;
					}
				}
				$player->sendMessage("§eБлижайшие игроки:§c" . $near . "§e.");
			} else {
				$player->sendMessage("§eИгроки не найдены!");
			}
		} elseif ($cmd->getName() == "console") {
			if (isset($this->cfg->getAll()[strtolower($player->getName())]["console"])) {
				if ($this->cfg->getAll()[strtolower($player->getName())]["console"]) {
					$console = false;
					$this->cfg->set(strtolower($player->getName()), array(
						"ach" => array(
							"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
							"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
							"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
							"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
						),
						"console" => false,
						"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
					));
					$this->cfg->save();
				} else {
					$console = true;
					$this->cfg->set(strtolower($player->getName()), array(
						"ach" => array(
							"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
							"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
							"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
							"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
						),
						"console" => true,
						"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
					));
					$this->cfg->save();
				}
			} else {
				$console = true;
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
						"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
						"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
						"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
					),
					"console" => true,
					"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
				));
				$this->cfg->save();
			}
			if ($console) {
				$player->sendMessage("§eКонсоль успешно включена!");
			} else {
				$player->sendMessage("§eКонсоль успешно выключена!");
			}
		} elseif ($cmd->getName() == "notp") {
			if (isset($this->cfg->getAll()[strtolower($player->getName())]["notp"])) {
				if ($this->cfg->getAll()[strtolower($player->getName())]["notp"]) {
					$notp = false;
					$this->cfg->set(strtolower($player->getName()), array(
						"ach" => array(
							"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
							"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
							"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
							"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
						),
						"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
						"notp" => false
					));
					$this->cfg->save();
				} else {
					$notp = true;
					$this->cfg->set(strtolower($player->getName()), array(
						"ach" => array(
							"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
							"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
							"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
							"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
						),
						"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
						"notp" => true
					));
					$this->cfg->save();
				}
			} else {
				$notp = true;
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
						"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
						"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
						"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
					),
					"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
					"notp" => true	
				));
				$this->cfg->save();
			}
			if ($notp) {
				$player->sendMessage("§eТелепортации успешно выключены!");
			} else {
				$player->sendMessage("§eТелепортации успешно включены!");
			}
		} elseif ($cmd->getName() == "rules") {
			$rules = array(
				"1.1 Читы запрещены.",
				"1.2 Гриферство запрещено.",
				"1.3 Оскорбления запрещены.",
				"1.4 Маты запрещены.",
				"1.5 Продажа доната запрещена.",
				"1.6 Порча биомов запрещена."
			);
			$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
			if ($api === null || $api->isDisabled()) {
				$player->sendMessage("§eFormAPI не установлен!");
				return false;
			}
			$form = $api->createSimpleForm(
				function(Player $player, $data = 0) {
					$result = $data;
					if ($result === null) {
						return;
					}
					switch ($result) {
						case 0:
							$player->sendMessage("§eМеню успешно закрыто!");
							return;
					}
			});
			$form->setTitle("§a§lПРАВИЛА СЕРВЕРА");
			$text = "";
			foreach ($rules as $rule) {
				$text .= "\n§c§l" . $rule;
			}
			$form->setContent("§eПравила сервера:" . $text);
			$form->addButton("Закрыть");
			$form->sendToPlayer($player);
		} elseif ($cmd->getName() == "ach") {
			$break = " ";
			$place = " ";
			$place2 = " ";
			$ownDamage = " ";
			$donate = " ";
			if (isset(
				$this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"]
			)) {
				if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] == "passed") {
					$break = "§7(§c§lПОЛУЧЕНО§r§7)";
				}
			}
			if (isset(
				$this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]
			)) {
				if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] == "passed") {
					$place = "§7(§c§lПОЛУЧЕНО§r§7)";
				}
			}
			if (isset(
				$this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]
			)) {
				if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] == "passed") {
					$place2 = "§7(§c§lПОЛУЧЕНО§r§7)";
				}
			}
			if (isset(
				$this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]
			)) {
				if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] == "passed") {
					$ownDamage = "§7(§c§lПОЛУЧЕНО§r§7)";
				}
			}
			if ($player->hasPermission("system.donate")) {
				$donate = "§7(§c§lПОЛУЧЕНО§r§7)";
			}
			eval(base64_decode("JG5ldyA9ICLCpzcowqdjwqds0J/QntCb0KPQp9CV0J3QnsKncsKnNykiOw=="));
			$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
			if ($api === null || $api->isDisabled()) {
				$player->sendMessage("§eFormAPI не установлен!");
				return false;
			}
			$form = $api->createSimpleForm(
				function(Player $player, int $data = 0) {
					$result = $data;
					if ($result === null) {
						return;
					}
					switch ($result) {
						case 0:
							$player->sendMessage("§eМеню успешно закрыто!");
							return;
					}
			});
			$form->setTitle("§a§lДОСТИЖЕНИЯ");
			$form->setContent(
				"§eДостижения:\n" .
				"§a§lШАХТЁР§r " . $break . "\n" .
				"§a§lСТРОИТЕЛЬ§r " . $place . "\n" .
				"§a§lЛЕСОРУБ§r " . $place2 . "\n" .
				"§a§lПВПЕШЕР§r " . $ownDamage . "\n" .
				"§a§lДОНАТЕР§r " . $donate . "\n" .
				"§a§lНОВИЧОК§r " . $new
			);
			$form->addButton("Закрыть");
			$form->sendToPlayer($player);
		}
		return true;
	}

	public function onCommandPreprocess(PlayerCommandPreprocessEvent $event) {
		if (str_replace("/", "", $event->getMessage()) != $event->getMessage()) {
			$this->getServer()->getLogger()->info("§7[§e§lКОНСОЛЬ§r§7] " . $event->getPlayer()->getName() . ": §c" . $event->getMessage());
			foreach ($this->getServer()->getOnlinePlayers() as $players) {
				if (isset($this->cfg->getAll()[strtolower($players->getName())]["console"])) {
					if ($this->cfg->getAll()[strtolower($players->getName())]["console"]) {
						$players->sendMessage("§7[§e§lКОНСОЛЬ§r§7] " . $event->getPlayer()->getName() . ": §c" . $event->getMessage());
					}
				}
			}
		}
		$command = explode(" ", strtolower($event->getMessage()));
		if (isset($command[1])) {
			if (strtolower($command[0]) == "/tp") {
				if ($this->getServer()->getPlayer($command[1]) != null) {
					$players = $this->getServer()->getPlayer($command[1]);
					if (isset($this->cfg->getAll()[strtolower($players->getName())]["notp"])) {
						if ($this->cfg->getAll()[strtolower($players->getName())]["notp"]) {
							$event->getPlayer()->sendMessage("§eНельзя телепортироваться к этому игроку!");
							$event->setCancelled();
						}
					}
				}
			}
		}
	}

	public function onJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		$event->setJoinMessage(null);
	}

	public function onQuit(PlayerQuitEvent $event){
		$player = $event->getPlayer();
		$event->setQuitMessage(null);
	}

	public function onBreak(BlockBreakEvent $event) {
		$player = $event->getPlayer();
		$blocks = $event->getBlock()->getId();
        $wood = [Block::WOOD, Block::WOOD2];
        if (in_array($blocks, $wood)) {
			if (!isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"])) {
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"place2" => 1,
						"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
						"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
						"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
					),
					"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
					"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
				));
				$this->cfg->save();
				return;
			}
			if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] != "passed") {
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"place2" => ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] + 1),
						"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
						"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
						"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
					),
					"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
					"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
				));
				$this->cfg->save();
				if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] >= 25) {
					$player->sendMessage("§a§lВЫ ПОЛУЧИЛИ ДОСТИЖЕНИЕ: §eВы срубили 25 дерева!");
					$this->cfg->set(strtolower($player->getName()), array(
						"ach" => array(
							"place2" => "passed",
							"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
							"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
							"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
						),
						"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
						"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
					));
					$this->cfg->save();
				}
			}
		}
		if (!isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"])) {
			$this->cfg->set(strtolower($player->getName()), array(
				"ach" => array(
					"break" => 1,
					"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
					"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
					"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
				),
				"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
				"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
			));
			$this->cfg->save();
			return;
		}
		if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] != "passed") {
			$this->cfg->set(strtolower($player->getName()), array(
				"ach" => array(
					"break" => ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] + 1),
					"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
					"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
					"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
				),
				"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
				"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
			));
			$this->cfg->save();
			if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] >= 500) {
				$player->sendMessage("§a§lВЫ ПОЛУЧИЛИ ДОСТИЖЕНИЕ: §eВы сломали 500 блоков!");
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"break" => "passed",
						"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
						"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
						"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
					),
					"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
					"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
				));
				$this->cfg->save();
			}
		}
	}

	public function onPlace(BlockPlaceEvent $event) {
		$player = $event->getPlayer();
		if (!isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"])) {
			$this->cfg->set(strtolower($player->getName()), array(
				"ach" => array(
					"place" => 1,
					"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
					"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
					"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
				),
				"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
				"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
			));
			$this->cfg->save();
			return;
		}
		if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] != "passed") {
			$this->cfg->set(strtolower($player->getName()), array(
				"ach" => array(
					"place" => ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] + 1),
					"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
					"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
					"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
				),
				"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
				"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
			));
			$this->cfg->save();
			if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] >= 250) {
				$player->sendMessage("§a§lВЫ ПОЛУЧИЛИ ДОСТИЖЕНИЕ: §eВы поставили 250 блоков!");
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"place" => "passed",
						"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
						"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1,
						"ownDamage" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] : 1
					),
					"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
					"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
				));
				$this->cfg->save();
			}
		}
	}

	public function onDamage(EntityDamageEvent $event) {
		$player = $event->getEntity();
		if ($player instanceof Player) {
			if (!isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"])) {
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"ownDamage" => 1,
						"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
						"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
						"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1
					),
					"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
					"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
				));
				$this->cfg->save();
				return;
			}
			if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] != "passed") {
				$this->cfg->set(strtolower($player->getName()), array(
					"ach" => array(
						"ownDamage" => ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] + 1),
						"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
						"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
						"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1
					),
					"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
					"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
				));
				$this->cfg->save();
				if ($this->cfg->getAll()[strtolower($player->getName())]["ach"]["ownDamage"] >= 60) {
					$player->sendMessage("§a§lВЫ ПОЛУЧИЛИ ДОСТИЖЕНИЕ: §eВы получили 60 ударов!");
					$this->cfg->set(strtolower($player->getName()), array(
						"ach" => array(
							"ownDamage" => "passed",
							"place" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place"] : 1,
							"place2" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["place2"] : 1,
							"break" => isset($this->cfg->getAll()[strtolower($player->getName())]["ach"]["damage"]) ? $this->cfg->getAll()[strtolower($player->getName())]["ach"]["break"] : 1
						),
						"console" => isset($this->cfg->getAll()[strtolower($player->getName())]["console"]) ? $this->cfg->getAll()[strtolower($player->getName())]["console"] : false,
						"notp" => isset($this->cfg->getAll()[strtolower($player->getName())]["notp"]) ? $this->cfg->getAll()[strtolower($player->getName())]["notp"] : false
					));
					$this->cfg->save();
				}
			}
		}
	}
}