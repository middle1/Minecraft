<?php

 /*
 * Плагин был написан группой NewPlugins.
 * Полное или частичное копирование запрещено.
 */

namespace BlusterySasha\System;

use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\item\WrittenBook;
use pocketmine\item\Item;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

	public function onEnable() {
		if (!is_dir($this->getDataFolder())) {
			mkdir($this->getDataFolder());
		}
		$this->saveDefaultConfig();
		$this->cfg = (new Config($this->getDataFolder(). "config.yml", Config::YAML, [
			"page.1" => "Текст",
			"page.2" => "Текст"
		]))->getAll();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	
	public function onCommand(CommandSender $s, Command $cmd, string $label, array $args) : bool {
		if (!$s instanceof Player) {
			$s->sendMessage("Пожалуйста, зайдите в игру!");
			return false;
		}
		switch (strtolower($cmd->getName())) {
			case "tutorial":
				$s->sendMessage("§7Вам успешно выдана книга!");
        		$item = Item::get(Item::WRITTEN_BOOK, 0, 1);
        		$item->setTitle("Информация о сервере");
        		$item->setPageText(0, $this->cfg['page.1']);
        		$item->setPageText(1, $this->cfg['page.2']);
        		$item->setAuthor("Server");
        		$s->getInventory()->addItem($item);
				break;
		}
		return true;
	}
}
?>