<?php

 /*
 * Плагин был написан группой NewPlugins.
 * Полное или частичное копирование запрещено.
 */

namespace Commands\System;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\entity\Entity;

class Main extends PluginBase implements Listener {

	protected $vanish = [];
	
	public function onCommand(CommandSender $s, Command $cmd, string $label, array $args) : bool {
		if (!($s instanceof Player)) {
			$s->sendMessage("Пожалуйста, зайдите в игру!");
			return false;
		}
		switch ($cmd->getName()) {
			case "fly":
				if (!$s->isCreative()) {
					$s->sendMessage($s->getAllowFlight() === false ? "§e§lПолёт успешно включён!§r" : "§e§lПолёт успешно выключен!§r");
					$s->setAllowFlight($s->getAllowFlight() === false ? true : false);
					$s->setFlying($s->isFlying() === false ? true : false);
					return false;
				}
				$s->sendMessage("§e§lВы в креативе!§r");
				break;
			case "vanish":
				if (!isset($this->vanish[strtolower($s->getName())])) {
					$this->vanish[strtolower($s->getName())] = true;
					$s->setDataFlag(Entity::DATA_FLAGS, Entity::DATA_FLAG_INVISIBLE, true);
					$s->setNameTagVisible(false);
					$s->sendMessage("§e§lВы успешно включили невидимость!§r");
				} elseif (isset($this->vanish[strtolower($s->getName())])) {
					unset($this->vanish[strtolower($s->getName())]);
					$s->setDataFlag(Entity::DATA_FLAGS, Entity::DATA_FLAG_INVISIBLE, false);
					$s->setNameTagVisible(true);
					$s->sendMessage("§e§lВы успешно отключили невидимость!§r");
				}
				break;
			case "gm":
				if (isset($args[0])) {
					switch ($args[0]) {
						case "0":
							$s->setGamemode(0);
							$s->sendMessage("§e§lВы успешно перешли в режим выживания!§r");
							break;
						case "1":
							$s->setGamemode(1);
							$s->sendMessage("§e§lВы успешно перешли в творческий режим!§r");
							break;
						case "2":
							$s->setGamemode(2);
							$s->sendMessage("§e§lВы успешно перешли в режим приключений!§r");
							break;
						case "3":
							$s->setGamemode(3);
							$s->sendMessage("§e§lВы успешно перешли в режим наблюдателя!§r");
							break;
						default:
							$s->sendMessage("§e§lРежим не найден!§r" . PHP_EOL .
								"§e§lИспользование: §c/gm <0, 1, 2, 3>§e.§r"
							);
							break;
					}
				} else {
					$s->sendMessage("§e§lИспользование: §c/gm <0, 1, 2, 3>§e.§r");
				}
				break;
		}
		return true;
	}
}
?>