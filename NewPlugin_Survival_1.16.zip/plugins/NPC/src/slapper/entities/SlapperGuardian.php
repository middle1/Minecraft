<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperGuardian extends SlapperEntity {

    const TYPE_ID = 49;
    const HEIGHT = 0.85;

}
