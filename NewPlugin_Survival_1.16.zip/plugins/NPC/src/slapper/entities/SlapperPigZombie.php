<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperPigZombie extends SlapperEntity {

    const TYPE_ID = 36;
    const HEIGHT = 1.95;

}