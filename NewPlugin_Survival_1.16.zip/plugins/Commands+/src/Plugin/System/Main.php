<?php
namespace Plugin\System;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\entity\EffectInstance;
use pocketmine\utils\TextFormat;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\entity\Effect;
use pocketmine\event\block\BlockPlaceEvent;

class Main extends PluginBase implements Listener {

	public function onEnable() {
		$this->enabled = array();
		$this->hunger = array();
		$this->tntplayers = array();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	public function onDisable() {
		unset($this->enabled, $this->tntplayers, $this->lavaplayers);
	}

	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
		if (!($sender instanceof Player)) {
			$sender->sendMessage("§e§lТолько в игре!");
			return false;
		}
		if ($cmd->getName() == "god") {
			if (!isset($this->enabled[strtolower($sender->getName())])) {
				$this->enabled[strtolower($sender->getName())] = false;
			}
			$this->enabled[strtolower($sender->getName())] = !$this->enabled[strtolower($sender->getName())];
			if ($this->enabled[strtolower($sender->getName())]) {
				$sender->sendMessage("§e§lРежим Бога успешно включен!");
			} else {
				$sender->sendMessage("§e§lРежим Бога успешно выключен!");
			}
			return true;
		} elseif ($cmd->getName() == "hunger") {
			if (!isset($this->hunger[strtolower($sender->getName())])) {
				$this->hunger[strtolower($sender->getName())] = false;
			}
			$this->hunger[strtolower($sender->getName())] = !$this->hunger[strtolower($sender->getName())];
			if ($this->hunger[strtolower($sender->getName())]) {
				$sender->sendMessage("§e§lТеперь у Вас не будет тратиться голод!");
			} else {
				$sender->sendMessage("§e§lТеперь у Вас будет тратиться голод!");
			}
			return true;
		} elseif ($cmd->getName() == "buyeffect") {
			$player = $sender;
			if (!isset($args[0])) {
				$sender->sendMessage("§e§lУкажите эффект!");
				return false;
			}
			$args[0] = strtolower($args[0]);
			$economyAPI = Server::getInstance()->getPluginManager()->getPlugin('EconomyAPI');
			if ($args[0] == "regen") {
				if ($economyAPI->myMoney($player) >= 15000) {
					$economyAPI->reduceMoney($player, 15000);
					$sender->sendMessage("§e§lВы успешно купили эффект на 15 минут!");
					$instance = new EffectInstance(Effect::getEffect(10), 18000, 1, true);
					$player->addEffect($instance);
				} else {
					$sender->sendMessage("§e§lНедостаточно денег!");
					$sender->sendMessage("§e§lВаш баланс: §c" . $economyAPI->myMoney($player) . "§e.");
				}
			} elseif ($args[0] == "force") {
				if ($economyAPI->myMoney($player) >= 10000) {
					$economyAPI->reduceMoney($player, 10000);
					$sender->sendMessage("§e§lВы успешно купили эффект на 15 минут!");
					$instance = new EffectInstance(Effect::getEffect(5), 18000, 1, true);
					$player->addEffect($instance);
				} else {
					$sender->sendMessage("§e§lНедостаточно денег!");
					$sender->sendMessage("§e§lВаш баланс: §c" . $economyAPI->myMoney($player) . "§e.");
				}
			} elseif ($args[0] == "absorp") {
				if ($economyAPI->myMoney($player) >= 5000) {
					$economyAPI->reduceMoney($player, 5000);
					$sender->sendMessage("§e§lВы успешно купили эффект на 15 минут!");
					$instance = new EffectInstance(Effect::getEffect(22), 18000, 1, true);
					$player->addEffect($instance);
				} else {
					$sender->sendMessage("§e§lНедостаточно денег!");
					$sender->sendMessage("§e§lВаш баланс: §c" . $economyAPI->myMoney($player) . "§e.");
				}
			} elseif ($args[0] == "jump") {
				if ($economyAPI->myMoney($player) >= 7000) {
					$economyAPI->getInstance()->reduceMoney($player, 7000);
					$sender->sendMessage("§e§lВы успешно купили эффект на 15 минут!");
					$instance = new EffectInstance(Effect::getEffect(8), 18000, 1, true);
					$player->addEffect($instance);
				} else {
					$sender->sendMessage("§e§lНедостаточно денег!");
					$sender->sendMessage("§e§lВаш баланс: §c" . $economyAPI->myMoney($player) . "§e.");
				}
			} else {
				$sender->sendMessage("§e§lЭффект не найден!");
			}
			return true;
		}
	}

	/**
	* @param EntityDamageEvent $event
	*
	* @priority HIGHEST
	* @ignoreCancelled true
	*/
	public function onDamage(EntityDamageEvent $event) {
		$entity = $event->getEntity();
		if ($entity instanceof Player && isset($this->enabled[strtolower($entity->getName())])) {
			if ($this->enabled[strtolower($entity->getName())]) {
				$event->setCancelled();
			}
		}
	}

	/**
	* @param BlockPlaceEvent $event
	*
	* @priority HIGHEST
	* @ignoreCancelled true
	*/
	public function onPlace(BlockPlaceEvent $event) {
        $player = $event->getPlayer();
		$blocks = $event->getBlock()->getId();
		if (in_array($blocks, [Block::TNT])) {
			if (!isset($this->tntplayers[strtolower($player->getName())])) {
				$this->tntplayers[strtolower($player->getName())] = 1;
			} else {
				if ($this->tntplayers[strtolower($player->getName())] >= 5) {
					$player->sendMessage("§e§lНельзя ставить так много динамита!");
					$event->setCancelled();
				} else {
					$this->tntplayers[strtolower($player->getName())] = ($this->tntplayers[strtolower($player->getName())] + 1);
				}
			}
			return;
		}
	}

	/**
	* @param PlayerExhaustEvent $event
	*
	* @priority HIGHEST
	* @ignoreCancelled true
	*/
	public function onHunger(PlayerExhaustEvent $event) {
		$entity = $event->getEntity();
		if ($entity instanceof Player && isset($this->hunger[strtolower($entity->getName())])) {
			if ($this->hunger[strtolower($entity->getName())]) {
				$event->setCancelled();
			}
		}
	}
}