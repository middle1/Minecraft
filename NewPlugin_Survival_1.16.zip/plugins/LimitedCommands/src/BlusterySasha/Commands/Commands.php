<?php

declare(strict_types=1);

namespace BlusterySasha\Commands;

use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class Commands extends PluginBase implements Listener {

	private $cooldowns = [];

	public function onEnable() : void {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->config = new Config($this->getDataFolder() . "config.yml", Config::YAML, array(
			"commands" => array(
				"/ban",
				"/kick",
				"/bans",
				"/iban",
				"/freeze",
				"/mute",
				"/unmute",
				"/unfreeze",
				"/kill"
			),
			"cooldowns" => array(
				"/ban" => 4000,
				"/kick" => 2500,
				"/bans" => 480,
				"/iban" => 2500,
				"/freeze" => 2500,
				"/mute" => 2500,
				"/unmute" => 480,
				"/unfreeze" => 480,
				"/kill" => 12000
			)
		));
	}

	public function PlayerCommandPreprocess(PlayerCommandPreprocessEvent $event) {
		$player = $event->getPlayer();
		$sender = $event->getPlayer();
		$cmd = explode(" ", trim(strtolower($event->getMessage())));
		foreach ($this->config->getAll()["commands"] as $commands) {
			if (strtolower($cmd[0]) == strtolower($commands)) {
				$uuid = $player->getUniqueId()->toString();
				if (isset($this->cooldowns[$uuid][strtolower($commands)])) {
					$duration = $this->cooldowns[$uuid][strtolower($commands)] + (int) $this->config->getAll()["cooldowns"][strtolower($commands)];
					if ($duration >= time()) {
						$sender->sendMessage("§cВы сможете использовать эту команду через " . ($duration - time()) . " секунд.");
						$event->setCancelled();
					} else {
						$this->cooldowns[$uuid][strtolower($commands)] = time();
					}
				} else {
					$this->cooldowns[$uuid][strtolower($commands)] = time();
				}
				break;
			}
		}
	}
}