<?php
namespace NP;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use pocketmine\inventory\Inventory;
use pocketmine\utils\Color;
use pocketmine\item\Armor;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\Player;
use pocketmine\Server;

class DC extends PluginBase implements Listener {
	public $config,
		$cases,
		$placedCases,
		$users,
		$eco,
		$setting = [
			'set' => false,
			'case' => false
		];

	public function onEnable() {
		$f = $this->getDataFolder();
		$pManager = $this->getServer()->getPluginManager();
		if(!is_dir($f)) {
			@mkdir($f);
		}
		$this->saveResource('config.yml');
		$this->saveResource('cases.yml');
		$this->config = (new Config($f . 'config.yml', Config::YAML))->getAll();
		$this->cases = (new Config($f . 'cases.yml', Config::YAML))->getAll();
		$this->placedCases = (new Config($f . 'placedCases.yml', Config::YAML))->getAll();
		$this->usersConfig = (new Config($f . 'users.yml', Config::YAML));
		$this->users = (new Config($f . 'users.yml', Config::YAML))->getAll();
		$this->eco = $pManager->getPlugin("EconomyAPI") ?? $pManager->getPlugin("PocketMoney") ?? $pManager->getPlugin("MassiveEconomy") ?? null;
		unset($pManager);
		if ($this->eco === null) {
			$this->getLogger()->warning('Нет плагина на экономику.');
		} else {
			$this->getLogger()->info('Плагин на экономику: '.$this->eco->getName());
		}
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
		$name = strtolower($sender->getName());
		switch (strtolower($command->getName())) {
			case 'casebalance':
				if (!$sender instanceof Player) {
					$sender->sendMessage('§cТолько для игроков!');
					return false;
				}
				$sender->sendMessage(str_replace('{keys}', $this->users[$name], $this->config['messages']['keys']));
				break;
			case 'caseset':
				if (!$sender instanceof Player) {
					$sender->sendMessage('§cТолько для игроков!');
					return false;
				}
				if (!$sender->hasPermission('adc.admin')) {
					return true;
				}
				if (count($args) != 1) {
					$sender->sendMessage("§l§7[§eКейсы§7]§r §eИспользование: /caseset <имя кейса>");
					return true;
				}
				$case = strtolower($args[0]);
				if (!isset($this->cases[$case])) {
					$sender->sendMessage("§l§7[§eКейсы§7]§r §eТакого кейса не существует");
					return true;
				}
				$this->setting['set'] = true;
				$this->setting['case'] = $case;
				$sender->sendMessage("§l§7[§eКейсы§7]§r §eНажмите туда, куда хотите установить кейс");
				break;
			case 'casecoins':
				if (!$this->config['param']['players']) {
					if ($sender instanceof Player) {
						return true;
					}
				}
				if (count($args) != 2) {
					$sender->sendMessage("§l§7[§eКейсы§7]§r §eИспользование: /cc <ник> <количество>");
					return true;
				}
				$name = strtolower($args[0]);
				if (isset($this->users[$name])) {
					$this->users[$name] += (int) $args[1];
				} else {
					$this->usersConfig->set(array(
						$name => (int) $args[1]
					));
				}
				$sender->sendMessage("§l§7[§eКейсы§7]§r §eИгроку §b$name §eвыдано §b" . (int) $args[1] . " §eключей");
				$this->getLogger()->info("§l§7[§eКейсы§7]§r §eИгроку §b$name §eвыдано §b" . (int) $args[1] . " §eключей");
				$this->save();
				break;
		}
		return true;
	}

	public function onPlayerInteract(PlayerInteractEvent $event) {
		$player = $event->getPlayer();
		$name = strtolower($player->getName());
		$block = $event->getBlock();
		$x = $block->getX();
		$y = $block->getY();
		$z = $block->getZ();
		if ($player->hasPermission('adc.admin') or $player->isOp()) {
			if ($this->setting['set']) {
				$event->setCancelled(true);
				$this->setting['set'] = false;
				$cName = $this->setting['case'];
				$case = $this->cases[$cName];
				$this->placedCases["$x.$y.$z"] = $case;
				$this->placedCases["$x.$y.$z"]['world'] = strtolower($player->getLevel()->getName());
				$this->saveCase();
				$player->sendMessage("§l§7[§eКейсы§7]§r §eКейс §b$cName §eустановлен на §b$x $y $z");
				$player->sendMessage("§l§7[§eКейсы§7]§r §eУдалять кейс через конфиг!");
				$this->addText($player, ['x' => $x + 0.5, 'y' => $y + 1.2, 'z' => $z + 0.6], $case['title']);
				return true;
			}
		}
		if (isset($this->placedCases["$x.$y.$z"])) {
			$event->setCancelled(true);
			if ($this->users[$name] < 1) {
				$player->sendMessage($this->config['messages']['noKey']);
				return true;
			}
			$this->users[$name]--;
			$case = $this->placedCases["$x.$y.$z"];
			$win = $this->getWin($case['items']);
			switch ($case['type']) {
				case 'donate':
					$this->getServer()->getInstance()->dispatchCommand(new ConsoleCommandSender(), str_replace('{player}', $name, $win['command']));
					$win['count'] = 1;
					break;
				case 'money':
					$count = explode('/', $win['count']);
					if (!isset($count[1]))
						$count[1] = $count[0];
					$count = mt_rand($count[0], $count[1]);
					$win['count'] = $count;
					$this->eco->giveMoney($name, $count);
					break;
				case 'item':
					$item = $this->item($win);
					$player->getInventory()->addItem($item);
					break;
			}
			$player->sendMessage(str_replace(['{item}', '{count}'], [$win['chat'], $win['count']], $this->config['messages']['win']));
			if ($this->config['param']['broadcast']) {
				$this->getServer()->broadcastMessage(str_replace(['{player}', '{item}', '{count}'], [$player->getName(), $win['chat'], $win['count']], $this->config['messages']['broadcast']));
			}
			$this->save();
		}
	}

	public function onPlayerJoin(PlayerJoinEvent $event) {
		$name = strtolower($event->getPlayer()->getName());
		if (!isset($this->users[$name]))
			$this->users[$name] = $this->config['param']['defaultKeys'];
	}

	public function openCase($player, $amount) {
		if ($this->eco === null) {
			return "§cПлагин на экономику отсутствует!";
		}
		$this->eco->setMoney($player, $this->getMoney($player) - $amount);
	}

	/**
	 * @param string $player
	 * @param integer $amount
	 */
	public function giveMoney($player, $amount) {
		if ($this->eco === null) {
			return "§cПлагин на экономику отсутствует!";
		}
		$this->eco->setMoney($player, $this->getMoney($player) + $amount);
	}

	/**
	 * @param  string $player
	 * @return integer $balance
	 */
	public function getMoney($player) {
		switch ($this->eco->getName()) {
			case 'EconomyAPI':
				$balance = $this->eco->myMoney($player);
				break;
			case 'PocketMoney':
				$balance = $this->eco->getMoney($player);
				break;
			case 'MassiveEconomy':
				$balance = $this->eco->getMoney($player);
				break;
			default:
				$balance = 0;
		}
		return $balance;
	}

	/**
	 * @var string $name
	 * @return mixed
	 */
	public function getEconomyPlugin($name = false) {
		if ($name) {
			return $this->eco->getName();
		}
		return $this->eco;
	}

	private function getWin($list) {
		do {
			$item = $list[array_rand($list)];
			$chance = mt_rand(1, 100);
			if ($chance <= $item['chance']) {
				return $item;
			}
		} while ($chance > $item['chance']);
	}

	public function onPlayerRespawn(PlayerRespawnEvent $event) {
		$level = mb_strtolower($event->getPlayer()->getLevel()->getName());
		foreach($this->placedCases as $coords => $case) {
			if($case['world'] != $level) {
				$coords = explode('.', $coords);
				$this->addText($event->getPlayer(), ['x' => $coords[0] + 0.5, 'y' => $coords[1] + 1.2, 'z' => $coords[2] + 0.6], $case['title']);
			}
		}
	}

	private function addText($player, $coords, $text) {
		$player->getLevel()->addParticle(new FloatingTextParticle(new Vector3($coords['x'], $coords['y'], $coords['z']), '', str_replace('\n', "\n", $text)));
	}

	private function item($i) {
		if (empty($i['damage'])) {
			$i['damage'] = 0;
		}
		if (empty($i['count'])) {
			$i['count'] = 1;
		}
		$item = Item::get($i['id'], $i['damage'], $i['count']);
		if(!empty($i['name'])) {
			$item->setCustomName($i['name']);
		}
		if ($item->isArmor()) {
			if (!empty($i['color'])) {
				$rgb = explode(' ', $i['color']);
				if (count($rgb) == 3) {
					$item->setCustomColor(Color::getRGB($rgb[0], $rgb[1], $rgb[2]));
				}
			}
		}
 		if (isset($i['enchants'])) {
 			if (is_array($i['enchants'])) {
 				foreach ($i['enchants'] as $ench) {
 					if (!isset($ench['level'])) {
						$ench['level'] = 1;
					}
 					$ench = Enchantment::getEnchantment($ench['id'])->setLevel($ench['level']);
 					$item->addEnchantment($ench);
 				}
 			}
 		}
 		return $item;
	}

	public function saveCase() {
		$cfg = new Config($this->getDataFolder().'placedCases.yml', Config::YAML);
		$cfg->setAll($this->placedCases);
		$cfg->save();
		unset($cfg);
	}

	public function save() {
		$cfg = new Config($this->getDataFolder().'users.yml', Config::YAML);
		$cfg->setAll($this->users);
		$cfg->save();
		unset($cfg);
	}
}
?>