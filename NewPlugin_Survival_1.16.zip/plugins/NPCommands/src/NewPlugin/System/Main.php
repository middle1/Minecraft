<?php

 /*
 * Плагин был написан группой NewPlugins.
 * Полное или частичное копирование запрещено.
 */

namespace NewPlugin\System;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\inventory\PlayerInventory;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\level\Location;

class Main extends PluginBase implements Listener {

	public function onEnable() {
		$this->enabled = array();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	public function onDisable() {
		unset($this->enabled);
	}

	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
		if ($sender instanceof Player) {
			if (strtolower($cmd->getName()) == "pickup") {
				if (!isset($this->enabled[strtolower($sender->getName())])) {
					$this->enabled[strtolower($sender->getName())] = true;
					$sender->sendMessage("§e§lРежим успешно включен!");
				} else {
					$this->enabled[strtolower($sender->getName())] = !$this->enabled[strtolower($sender->getName())];
					if ($this->enabled[strtolower($sender->getName())]) {
						$sender->sendMessage("§e§lРежим успешно включен!");
					} else {
						$sender->sendMessage("§e§lРежим успешно выключен!");
					}
				}
				return true;
			} elseif (strtolower($cmd->getName()) == "a") {
				if (!isset($args[0])) {
					$sender->sendMessage("§e§lУкажите сообщение!");
					return false;
				}
				foreach ($this->getServer()->getOnlinePlayers() as $players) {
					if ($players->hasPermission("system.donatechat")) {
						$players->sendMessage("§7(§cDONATECHAT§7) §e" . $sender->getName() . "§7 написал: §e" . $args[0]);
					}
				}
				return true;
			} elseif (strtolower($cmd->getName()) == "tpcome") {
				if (!$sender->hasPermission("system.tpcome")) {
					$sender->sendMessage("§e§lНедостаточно прав!");
					return false;
				}
				if (!isset($args[0])) {
					$sender->sendMessage("§e§lУкажите игрока!");
					return false;
				}
				if ($this->getServer()->getPlayer($args[0]) === null) {
					$sender->sendMessage("§e§lУкажите игрока!");
					return false;
				}
				$sender->sendMessage("§e§lИгрок успешно телепортирован!");
				$this->getServer()->getPlayer($args[0])->teleport($sender->getLocation());
				return true;
			}
		} else {
			$sender->sendMessage("§e§lТолько в игре!");
		}
		return true;
	}

	/**
	* @param InventoryPickupItemEvent $event
	*
	* @priority HIGHEST
	* @ignoreCancelled true
	*/
	public function onPickUp(InventoryPickupItemEvent $event) {
		if (!isset($this->enabled[strtolower($event->getInventory()->getHolder()->getName())])) {
			$this->enabled[strtolower($event->getInventory()->getHolder()->getName())] = false;
		} else if ($this->enabled[strtolower($event->getInventory()->getHolder()->getName())]) {
			$event->setCancelled();
		}
	}
}