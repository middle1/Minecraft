<?php

declare(strict_types = 1);

namespace BlusterySasha\Repair\Commands;

use BlusterySasha\Repair\Main;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class RepairCommand extends PluginCommand {
	
	/** @var Main $plugin */
	private $plugin;
	
	/**
	 * RepairCommand constructor.
	 *
	 * @param string $name
	 * @param Main   $plugin
	 */
	public function __construct(string $name, Main $plugin) {
		parent::__construct($name, $plugin);
		$this->setDescription("Починить предмет");
		$this->setUsage("/repair [all:hand]");
		$this->setAliases(["fix"]);
		$this->setPermission("repair.command.use");
		$this->plugin = $plugin;
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string        $alias
	 * @param array         $args
	 * @return bool
	 */
	public function execute(CommandSender $sender, string $alias, array $args): bool {
		if(!$this->testPermission($sender)) {
			return true;
		}
		if(!$sender instanceof Player){
			$sender->sendMessage("Команда работает только в игре!");
			return true;
		}
		$a = "hand";
		if (isset($args[0])){
			$a = strtolower($args[0]);
		}
		if (!($a === "hand" || $a === "all")) {
			$sender->sendMessage("Использование: /repair [all/hand].");
			return true;
		}
		if ($a === "all") {
			if (!$sender->hasPermission("repair.command.use.all")){
				$sender->sendMessage("§cНедостаточно прав!");
				return true;
			}
			foreach ($sender->getInventory()->getContents() as $index => $item){
				if ($this->plugin->isRepairable($item)){
					if ($item->getDamage() > 0){
						$sender->getInventory()->setItem($index, $item->setDamage(0));
					}
				}
			}
			$m = "§eВсе предметы были восстановлены!";
			foreach ($sender->getArmorInventory()->getContents() as $index => $item){
				if ($this->plugin->isRepairable($item)){
					if($item->getDamage() > 0){
						$sender->getArmorInventory()->setItem($index, $item->setDamage(0));
					}
				}
			}
		} else {
			if(!$sender->hasPermission("repair.command.use")){
				$sender->sendMessage("§cНедостаточно прав!");
				return true;
			}
			$index = $sender->getInventory()->getHeldItemIndex();
			$item = $sender->getInventory()->getItem($index);
			if (!$this->plugin->isRepairable($item)) {
				$sender->sendMessage("§cДанный предмет нельзя починить!");
				return true;
			}
			if ($item->getDamage() > 0){
				$sender->getInventory()->setItem($index, $item->setDamage(0));
			} else {
				$sender->sendMessage("§cПредмет не сломан!");
			}
			$m = "§cПредмет успешно починен!";
		}
		$sender->sendMessage($m);
		return true;
	}
}
