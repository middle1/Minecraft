<?php

namespace onebone\economyjob;

use onebone\economyapi\EconomyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

class EconomyJob extends PluginBase implements Listener {
	/** @var EconomyJob */
	private static $instance;
	/** @var Config */
	private $jobs;
	/** @var Config */
	private $player;
	/** @var  EconomyAPI */
	private $api;

	/**
	 * @return EconomyJob
	 */
	public static function getInstance() {
		return static::$instance;
	}

	public function onEnable() {
		@mkdir($this->getDataFolder());
		if(!is_file($this->getDataFolder() . "jobs.yml")) {
			$this->jobs = new Config($this->getDataFolder() . "jobs.yml", Config::YAML, yaml_parse($this->readResource("jobs.yml")));
		}else{
			$this->jobs = new Config($this->getDataFolder() . "jobs.yml", Config::YAML);
		}
		$this->player = new Config($this->getDataFolder() . "players.yml", Config::YAML);

		$this->getServer()->getPluginManager()->registerEvents($this, $this);

		$this->api = EconomyAPI::getInstance();
		self::$instance = $this;
	}

	private function readResource($res) {
		$resource = $this->getResource($res);
		if(!is_resource($resource)) {
			return false;
		}
		$content = stream_get_contents($resource);
		@fclose($resource);
		return $content;
	}

	public function onDisable() {
		$this->player->save();
	}

	/**
	 * @priority MONITOR
	 * @ignoreCancelled true
	 * @param BlockBreakEvent $event
	 */
	public function onBlockBreak(BlockBreakEvent $event) {
		$player = $event->getPlayer();
		$block = $event->getBlock();

		$job = $this->jobs->get($this->player->get($player->getName()));
		if($job !== false) {
			if(isset($job[$block->getID() . ":" . $block->getDamage() . ":break"])) {
				$money = $job[$block->getID() . ":" . $block->getDamage() . ":break"];
				if($money > 0) {
					$this->api->addMoney($player, $money);
				}else{
					$this->api->reduceMoney($player, $money);
				}
			}
		}
	}

	/**
	 * @priority MONITOR
	 * @ignoreCancelled true
	 * @param BlockPlaceEvent $event
	 */
	public function onBlockPlace(BlockPlaceEvent $event) {
		$player = $event->getPlayer();
		$block = $event->getBlock();

		$job = $this->jobs->get($this->player->get($player->getName()));
		if($job !== false) {
			if(isset($job[$block->getID() . ":" . $block->getDamage() . ":place"])) {
				$money = $job[$block->getID() . ":" . $block->getDamage() . ":place"];
				if($money > 0) {
					$this->api->addMoney($player, $money);
				}else{
					$this->api->reduceMoney($player, $money);
				}
			}
		}
	}

	/**
	 * @return array
	 */
	public function getJobs() {
		return $this->jobs->getAll();
	}

	/**
	 * @return array
	 *
	 */
	public function getPlayers() {
		return $this->player->getAll();
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $params): bool {
		switch (array_shift($params)) {
			case "join":
				if(!$sender instanceof Player) {
					$sender->sendMessage("Только в игре!");
				}
				if($this->player->exists($sender->getName())) {
					$sender->sendMessage("Вы уже имеете работу!");
				}else{
					$job = array_shift($params);
					if(trim($job) === "") {
						$sender->sendMessage("Использование: /job join <название>");
						break;
					}
					if($this->jobs->exists($job)) {
						$this->player->set($sender->getName(), $job);
						$sender->sendMessage("Вы устроились на работу \"$job\".");
					}else{
						$sender->sendMessage("Работа \"$job\" не найдена.");
					}
				}
				break;
			case "retire":
				if(!$sender instanceof Player) {
					$sender->sendMessage("Только в игре!");
				}
				if($this->player->exists($sender->getName())) {
					$job = $this->player->get($sender->getName());
					$this->player->remove($sender->getName());
					$sender->sendMessage("Вы вышли с работы \"$job\".");
				}else{
					$sender->sendMessage("Вы не имеете работы!");
				}
				break;
			case "list":
				$sender->sendMessage("Список работ: miner, cutter, planter.");
				break;
			case "me":
				if(!$sender instanceof Player) {
					$sender->sendMessage("Только в игре!");
				}
				if($this->player->exists($sender->getName())) {
					$sender->sendMessage("Ваша работа: " . $this->player->get($sender->getName()));
				}else{
					$sender->sendMessage("Вы не работаете.");
				}
				break;
			default:
				$sender->sendMessage($command->getUsage());
		}
		return true;
	}
}
